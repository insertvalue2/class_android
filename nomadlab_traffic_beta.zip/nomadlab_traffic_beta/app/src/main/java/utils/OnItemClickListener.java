package utils;

public interface OnItemClickListener {
    void onItemClick(String deviceName, String macAddress);
}

